import { Product } from "../product-details/product";

export interface CartProduct {
    productDetails : Product,
    requiredQty : number
}
