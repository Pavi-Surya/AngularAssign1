import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared-service';
import { Product } from '../product-details/product';
import { CartProduct } from './cart-product';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})

export class CartComponent implements OnInit { 
  
  newProduct : Product = {
    id: 0,
    name: '',
    price: 0,
    quantity: 0
  };

  constructor(private sharedService: SharedService) { 
  }

  ngOnInit() : void {
    this.sharedService.newItem$.subscribe(value => {
      this.newProduct = value;
      if(this.newProduct.id != 0)
        this.addProductToCart(this.newProduct);
    });
  }

  tempItem : CartProduct = {
    productDetails: this.newProduct,
    requiredQty: 0
  };

  cartList : CartProduct [] = [];

  findItemFromCart(valueSent: Product): any {
    return this.cartList.find(item => item.productDetails.id==valueSent.id);
  }

  addProductToCart(valueSent: Product) {
    var tempValue = this.findItemFromCart(valueSent);
    var indexVal = this.cartList.indexOf(tempValue);
    if(indexVal != -1) {
      this.cartList[indexVal].requiredQty = this.cartList[indexVal].requiredQty + 1;
    } else {
      var tempItem : CartProduct = {
        productDetails: this.newProduct,
        requiredQty: 0
      };
      tempItem.productDetails = valueSent;
      tempItem.requiredQty = 1;
      this.cartList.push(tempItem);
    }
  }

}


