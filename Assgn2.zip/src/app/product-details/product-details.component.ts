import { Component } from '@angular/core';
import { SharedService } from '../shared-service';
import { Product } from './product';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent {

  constructor(private sharedService : SharedService) {}

  productList : Product [] = [{id : 11, name : "product1", price : 1000, quantity : 100}, {id : 12, name : "product2", price : 10300, quantity : 20}, {id : 13, name : "product3", price : 2000, quantity : 300}, {id : 14, name : "product4", price : 1000, quantity : 5}, {id : 15, name : "product5", price : 20000, quantity : 10}, {id : 16, name : "product6", price : 15000, quantity : 2}];
  errorMessage : string = "";
  
  addItem(product:Product) {
    if(product.quantity <= 10) {
      this.errorMessage = "Quantity is very Less";
    } else {
      this.errorMessage = "";
      product.quantity = product.quantity - 1;
      this.sharedService.addItemToCart(product);
    }
  }
}
