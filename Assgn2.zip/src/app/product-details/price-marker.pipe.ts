import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'priceMarker'
})
export class PriceMarkerPipe implements PipeTransform {

  transform(value: any): any {
    if(value.price <= 10000){
      return true;
    } else {
      return false;
    }
  }

}
