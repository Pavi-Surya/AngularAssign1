import { BehaviorSubject } from "rxjs";
import { Injectable } from "@angular/core";
import { Product } from "./product-details/product";

@Injectable({
    providedIn: 'root'
})

export class SharedService {

    private sharedValue = new BehaviorSubject<Product>({id: 0,name: '', price: 0, quantity: 0});
    newItem$ = this.sharedValue.asObservable();

    constructor() { }

    addItemToCart(value : Product){
        this.sharedValue.next(value);
    }
}
