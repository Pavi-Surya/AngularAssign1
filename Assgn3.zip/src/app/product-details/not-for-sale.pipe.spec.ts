import { NotForSalePipe } from './not-for-sale.pipe';

describe('NotForSalePipe', () => {
  it('create an instance', () => {
    const pipe = new NotForSalePipe();
    expect(pipe).toBeTruthy();
  });
});
