import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared-service';
import { Product } from './product';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor(private sharedService : SharedService) {}

  cartCount : number = 0;

  ngOnInit() : void {
    this.sharedService.count$.subscribe(value => {
      this.cartCount = value;
    });
  }

  productList : Product [] = [{id : 11, name : "product1", price : 1000, quantity : 100, errorMessage:""}, {id : 12, name : "product2", price : 10300, quantity : 20, errorMessage:""}, {id : 13, name : "product3", price : 2000, quantity : 300, errorMessage:""}, {id : 14, name : "product4", price : 1000, quantity : 5, errorMessage:""}, {id : 15, name : "product5", price : 20000, quantity : 10, errorMessage:""}, {id : 16, name : "product6", price : 15000, quantity : 2, errorMessage:""}];
  errorMessage : string = "";
  
  addItem(product:Product) {
    if(product.quantity <= 10) {
      product.errorMessage = "Quantity is very Less";
    } else {
      product.errorMessage = "";
      product.quantity = product.quantity - 1;
      this.sharedService.addItemToCart(product);
    }
  }
}
