import { BehaviorSubject } from "rxjs";
import { Injectable } from "@angular/core";
import { Product } from "./product-details/product";

@Injectable({
    providedIn: 'root'
})

export class SharedService {

    private sharedValueProduct = new BehaviorSubject<Product>({id: 0,name: '', price: 0, quantity: 0, errorMessage: ""});
    newItem$ = this.sharedValueProduct.asObservable();

    private sharedValueCount = new BehaviorSubject<number>(0);
    count$ = this.sharedValueCount.asObservable();

    constructor() { }

    addItemToCart(value : Product){
        this.sharedValueProduct.next(value);
    }

    pushCount(value : number) {
        this.sharedValueCount.next(value);
    }
}
