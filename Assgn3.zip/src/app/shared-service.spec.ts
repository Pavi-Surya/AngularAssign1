import { SharedService } from './shared-service';

describe('SharedService', () => {
  it('should create an instance', () => {
    expect(new SharedService()).toBeTruthy();
  });
});
