import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { PriceMarkerPipe } from './product-details/price-marker.pipe';
import { NotForSalePipe } from './product-details/not-for-sale.pipe';
import { CartComponent } from './cart/cart.component';
import { SharedService } from './shared-service';

const routes : Routes = [
  {
    path : '',
    component : AppComponent,
    children : [
      {path: '', redirectTo: 'viewProductList', pathMatch: 'full' },
      {path : 'viewProductList', component: ProductDetailsComponent},
      {path : 'viewCart', component : CartComponent}
    ]
  }
];

@NgModule({
  declarations: [
    AppComponent,
    ProductDetailsComponent,
    PriceMarkerPipe,
    NotForSalePipe,
    CartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forChild(routes)
  ],
  providers: [SharedService],
  bootstrap: [AppComponent],
  exports : [RouterModule]
})

export class AppModule { }
