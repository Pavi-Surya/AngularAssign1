import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from '../shared-service';
import { Product } from '../product-details/product';
import { CartProduct } from './cart-product';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})

export class CartComponent implements OnInit { 
  
  constructor(private sharedService : SharedService, private router : Router) { 
  }

  newProduct : Product = {
    id: 0,
    name: '',
    price: 0,
    quantity: 0,
    errorMessage: ""
  };

  tempItem : CartProduct = {
    productDetails: this.newProduct,
    requiredQty: 0
  };

  cartList : CartProduct [] = [];

  ngOnInit() {
    this.sharedService.newItem$.subscribe(value => {
      console.log("loading...");
      console.log(this.cartList);
      this.newProduct = value;
      if(this.newProduct.id != 0)
        this.addProductToCart(this.newProduct);
    });
  }

  findItemFromCart(valueSent: Product): any {
    return this.cartList.find(item => item.productDetails.id==valueSent.id);
  }

  addProductToCart(valueSent: Product) {
    var tempValue = this.findItemFromCart(valueSent);
    var indexVal = this.cartList.indexOf(tempValue);
    if(indexVal != -1) {
      this.cartList[indexVal].requiredQty = this.cartList[indexVal].requiredQty + 1;
    } else {
      var tempItem : CartProduct = {
        productDetails: this.newProduct,
        requiredQty: 0
      };
      tempItem.productDetails = valueSent;
      tempItem.requiredQty = 1;
      this.cartList.push(tempItem);
    }
    var totalCount = 0;
    this.cartList.forEach(item => {
      totalCount = totalCount + item.requiredQty;
    });
    this.sharedService.pushCount(totalCount);
  }

  goToProducts() {
    this.router.navigate(['viewProductList'])
  }

}


