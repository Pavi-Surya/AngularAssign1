import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StringFuncComponent } from './string-func.component';

describe('StringFuncComponent', () => {
  let component: StringFuncComponent;
  let fixture: ComponentFixture<StringFuncComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StringFuncComponent]
    });
    fixture = TestBed.createComponent(StringFuncComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
