import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-string-func',
  templateUrl: './string-func.component.html',
  styleUrls: ['./string-func.component.css']
})
export class StringFuncComponent  {
  
  stringInput : string = '';

}
