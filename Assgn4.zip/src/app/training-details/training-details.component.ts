import { Component, OnInit } from '@angular/core';
import { Training } from './training';
import { TrainingService } from './training.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-training-details',
  templateUrl: './training-details.component.html',
  styleUrls: ['./training-details.component.css']
})
export class TrainingDetailsComponent implements OnInit{

  trainingList : Training [] = [];

  constructor (private trainingService: TrainingService) {}
  
  getTrainingList() : void {
  this.trainingService.getTrainingList().subscribe((response) => {
    this.trainingList = response;
  });
  }

  sortTrainingList () {
    this.trainingList.sort((t1, t2) => t1.name.localeCompare(t2.name));
  }

  reverseSortTrainingList () {
    this.trainingList.sort((t1, t2) => t2.name.localeCompare(t1.name));
  }

  ngOnInit(): void {
    this.getTrainingList();
  }


}
