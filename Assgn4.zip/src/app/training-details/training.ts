export interface Training {
    id : number,
    name : string,
    mode : string,
    duration : number
}
