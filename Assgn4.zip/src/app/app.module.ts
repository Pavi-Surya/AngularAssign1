import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TrainingDetailsComponent } from './training-details/training-details.component';
import { HttpClientModule } from '@angular/common/http';
import { StringFuncComponent } from './string-func/string-func.component';
import { FormsModule } from '@angular/forms';
import { StringReversePipe } from './string-func/string-reverse.pipe';

@NgModule({
  declarations: [
    AppComponent,
    TrainingDetailsComponent,
    StringFuncComponent,
    StringReversePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
