import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from '../shared-service';
import { Product } from '../product-details/product';
import { CartProduct } from './cart-product';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})

export class CartComponent implements OnInit {

  constructor(private sharedService: SharedService, private router: Router) {
  }

  cartList: CartProduct[] = [];

  ngOnInit() {
    this.sharedService.newItem$.subscribe(value => {
      this.cartList = value;
    });
  }

  goToProducts() {
    this.router.navigate(['viewProductList'])
  }

}


