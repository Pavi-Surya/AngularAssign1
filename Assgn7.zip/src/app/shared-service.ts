import { BehaviorSubject } from "rxjs";
import { Injectable } from "@angular/core";
import { Product } from "./product-details/product";
import { CartProduct } from "./cart/cart-product";
import { ProductService } from "./product-details/product.service";

@Injectable({
    providedIn: 'root'
})

export class SharedService {

    private sharedValueProduct = new BehaviorSubject<CartProduct[]>([]);
    newItem$ = this.sharedValueProduct.asObservable();

    private sharedValueCount = new BehaviorSubject<number>(0);
    count$ = this.sharedValueCount.asObservable();

    constructor(private productService: ProductService) { }

    cartList: CartProduct[] = [];

    newProduct: Product = {
        id: 0,
        name: '',
        price: 0,
        quantity: 0,
        errorMessage: ""
    };

    findItemFromCart(valueSent: Product): any {
        return this.cartList.find(item => item.productDetails.id == valueSent.id);
    }

    addItemToCart(valueSent: Product) {
        this.newProduct = valueSent;
        if (this.newProduct.id != 0) {
            var tempValue = this.findItemFromCart(valueSent);
            var indexVal = this.cartList.indexOf(tempValue);
            if (indexVal != -1) {
                this.cartList[indexVal].requiredQty = this.cartList[indexVal].requiredQty + 1;
            } else {
                var tempItem: CartProduct = {
                    productDetails: this.newProduct,
                    requiredQty: 0
                };
                tempItem.productDetails = valueSent;
                tempItem.requiredQty = 1;
                this.cartList.push(tempItem);
            }
            var totalCount = 0;
            this.cartList.forEach(item => {
                totalCount = totalCount + item.requiredQty;
            });
            this.productService.updateProduct(valueSent).subscribe(response => {
                
            });
            this.sharedValueProduct.next(this.cartList);
            this.sharedValueCount.next(totalCount);
        }
    }

}
