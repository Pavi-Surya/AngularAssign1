import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  apiUrl: string = 'http://localhost:3000/products';

  constructor(private httpClient: HttpClient) { }

  getProductList(): Observable<any> {
    return this.httpClient.get<any>(this.apiUrl);
  }

  updateProduct(product: Product): Observable<any> {
    const url = `${this.apiUrl}/${product.id}`;
    return this.httpClient.put<any>(url, product);
  }
  
}
