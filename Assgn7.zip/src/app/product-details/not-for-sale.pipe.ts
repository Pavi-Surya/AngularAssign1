import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'notForSale'
})
export class NotForSalePipe implements PipeTransform {

  transform(value: any): any {
    if(value.quantity < 10){
      return value.name + " NOT FOR SALE";
    } else {
      return value.name;
    }
  }

}
