import { PriceMarkerPipe } from './price-marker.pipe';

describe('PriceMarkerPipe', () => {
  it('create an instance', () => {
    const pipe = new PriceMarkerPipe();
    expect(pipe).toBeTruthy();
  });
});
